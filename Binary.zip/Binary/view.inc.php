<!DOCTYPE html>
<html>

<head>

    <link rel="stylesheet" href="../css/style.css">
    <?php
    #linking the css file
    $cssFile = "css/style.css";
    echo "<link rel='stylesheet' href='" . $cssFile . "'>";


    ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>
    <?php
    class View extends Model
    {


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////

        #displaying the client's data
        public function showAllClient()
        {
            $datas = $this->getAllClient();
            // $results = $this->getAllLinkedContacts();
            if (empty($datas)) {
                echo "<p>
            No Clients found
            </p";
            } else {
                echo "<table border=''>
        <tr>
        <th>Firstname</th>
        <th>Client Code</th>
        <th>Linked Contact</th>
        </tr>";


                foreach ($datas as $data) {

                    echo "<tr>";
                    echo "<td>" . $data['first_name'] . "</td>";
                    echo "<td>" . $data['client_code'] . "</td>";
                    echo "<td>
                    <div class='containe'>
                    <button data-toggle='popover'  data-content=" . $data['email'] . " title='Dismissible popover'  >" . $data['linked_contacts'] . "</button> 
  
                    </div></td>";
                    echo "</tr>";
                }
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        #displaying the client's data

        public function showAllLinkedClient()
        {
            $datas = $this->getAllLinkedClient();
            // $results = $this->getAllLinkedContacts();
            if (empty($datas)) {
                echo "<p>
            No Clients found
            </p";
            } else {
                echo "<table border=''>
        <tr>
       
        <th>Firstname</th>
        <th>Email</th>
        
        </tr>";


                foreach ($datas as $data) {

                    echo "<tr>";

                    echo "<td>" . $data['first_name'] . " " . $data['last_name'] . "</td>";
                    echo "<td>" . $data['email'] . "</td>";

                    echo "<td>
                    <div class='contain'>
                    <a class='btn btn-danger' href='./controller.inc.php?client_id=" . $data['client_id'] . "'>Unlink</a>
                    </div></td>";
                    echo "</tr>";
                }
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////

        #displaying the client's data

        public function showAllContact()
        {

            $datas = $this->getAllContact();
            // $results = $this->getAllLinkedContacts();

            if (empty($datas)) {
                echo "<p>
                    No Contacts found
                    </p";
            } else {
                echo "<table border=''>
                <tr>
                <th>Firstname</th>
                <th>Lastname</th>               
                <th>Emails</th>               
                <th>Linked Clients</th>       
                </tr>";

                foreach ($datas as $data) {

                    echo "<tr>";
                    echo "<td>" . $data['first_name'] . "</td>";
                    echo "<td>" . $data['last_name'] . "</td>";
                    echo "<td>" . $data['email'] . "</td>";
                    echo "<td>
                            <div class='containe'>
                            <button data-toggle='popover'  data-content=" . $data['first_name'] . " title='Dismissible popover'  >" . $data['linked_clients'] . "</button> 
    
                            </div></td>";
                    echo "</tr>";
                }
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////

        #displaying the client's data

        public function showAllLinkedContact()
        {
            $datas = $this->getAllLinkedContacts();
            if (empty($datas)) {
                echo "<p>
                    No Contacts found
                    </p";
            } else {
                echo "<table border=''>
                <tr>
                <th>Firstname</th>
                <th>Client Code</th>              
                <th>Emails</th>
               
                </tr>";

                foreach ($datas as $data) {
                    echo "<tr>";
                    echo "<td>" . $data['first_name'] . "</td>";
                    echo "<td>" . $data['client_code'] . "</td>";
                    echo "<td>" . $data['email'] . "</td>";
                    echo "<td>
                            <div class='contain'>
                            <a class='btn btn-danger' href='./controller.inc.php?client_id=" . $data['client_id'] . "'>Unlink</a>
                               
                            </div></td>";
                    echo "</tr>";
                }
            }
        }
    }



    ?>

    <!-- <button data-toggle='popover'  title='Dismissible popover' Color='#212f3d'  data-content='popover'>".$data['linked_contacts']."</button> -->
    <!-- <a tabindex='0' class='btn btn-lg btn-danger' role='button' data-toggle='popover' data-trigger='focus' title='Dismissible popover' data-content='And here'>".$data['linked_contacts']."</a> -->
    <script>
        $(document).ready(function() {
            $('[data-toggle="popover"]').popover();
        });
    </script>


</body>



</html>