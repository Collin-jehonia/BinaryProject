<?php
include('MVC/model.inc.php');
include('MVC/controller.inc.php');
include('MVC/view.inc.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/style.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <?php
        $cssFile = "css/style.css";
        echo "<link rel='stylesheet' href='" . $cssFile . "'>";
    ?>
    <title>Document</title>
</head>

<body>
    <div class="tab">
        <button class="tablinks" onmouseover="openCity(event, 'Client')">Client Form</button>
        <button class="tablinks" onmouseover="openCity(event, 'View')">Client View</button>
        <button class="tablinks" onmouseover="openCity(event, 'Link')">Link Client To Contact Form</button>
       


    </div>

    <div id="Client" class="tabcontent">
        <h3>Client Form</h3>
        <form action="controller.inc.php" method="POST">
            <input type="text" name="fname" id="" placeholder="First name" required>
            <input type="text" name="lname" id="" placeholder="Last name" required>
            <input type="text" name="client_code" placeholder="Client code" id="" readonly>
            <input type="submit" name="save" value="save">
        </form>
    </div>
    <div id="Link" class="tabcontent">
        <h3>Link Client To Contact Form</h3>
        <form action="controller.inc.php" method="POST">

            <input type="email" name="email" id="" placeholder="email" required>
            <input type="text" name="code" id="" placeholder="client_code" required>
            <input type="submit" name="submit" value="submit">
        </form>
    </div>

    <div id="View" class="tabcontent">
    <h3>View of Client And Linked Contacts</h3>
        <?php
        $data = new View();
        $data->showAllClient();
        // $data ->getLinkedConacts();

    
        ?>
 <div id="View" class="tabcontent">
    <h3>View of Client And Linked Contacts</h3>
        <?php
        $data = new View();
        $data->showAllLinkedClient();
        // $data ->getLinkedConacts();

    
        ?>

        
    </div>
        
    </div>
    <?php
    $fullUrl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    if (strpos($fullUrl, "status=added_client")) {
    ?>
        <script>
            swal({
                title: "Successfully added client",
                icon: "success",
                button: "Ok",
            });
        </script>
    <?php
    } elseif (strpos($fullUrl, "status=client_exists")) {
    ?>
        <script>
            swal({
                title: "Client already exists!",
                icon: "error",
                button: "Ok",
            });
        </script>
    <?php
    }



    if (strpos($fullUrl, "status=client_contact_join")) {
        ?>
            <script>
                swal({
                    title: "Successfully linked client to contact",
                    icon: "success",
                    button: "Ok",
                });
            </script>
        <?php
        } elseif (strpos($fullUrl, "status=error_joining")) {
        ?>
            <script>
                swal({
                    title: "Error occured",
                    icon: "error",
                    button: "Ok",
                });
            </script>
        <?php
        }

        if (strpos($fullUrl, "status=unlink_client_contact")) {
            ?>
                <script>
                    swal({
                        title: "Successfully unlinked client from contact",
                        icon: "success",
                        button: "Ok",
                    });
                </script>
            <?php
            } elseif (strpos($fullUrl, "status=error_unlinkin")) {
            ?>
                <script>
                    swal({
                        title: "Error occured",
                        icon: "error",
                        button: "Ok",
                    });
                </script>
            <?php
            }
    ?>

    <script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
    </script>
</body>

</html>