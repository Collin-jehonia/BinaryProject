<?php

class Database
{
    //Variables
    private $servername;
    private $username;
    private $password;
    private $dbname;



    protected function connect()
    {
        $this->servername="localhost";
        $this->username="root";
        $this->password="";
        $this->dbname="binary_db";



        // Create connection
        $conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

         #checking if the database exists
         $database = mysqli_select_db($conn, "binary_db");

         if (empty($database)) {
             $sql = "CREATE DATABASE binary_db " ;
             if ($conn->query($sql) === true) {
                 echo "Database created successfully";
             } else {
                 echo "Error creating database: " . $conn->error;
             }
         }


        #sql to create table

        #creatig table contact
        $table_contact = "SELECT * FROM contact";

        $check_contact = mysqli_query($conn, $table_contact);

        if (!$check_contact) {
            $create_contact =  "CREATE TABLE contact(
              contact_id INT AUTO_INCREMENT not null primary key,
              email varchar(100) not null
          );" ;

     

            if ($conn->query($create_contact) === true) {
                echo "Table Contact created successfully";
            } else {
                echo "Error creating table Contact: " . $conn->error;
            }
        }

        
        #creatig table client
        $table_client = "SELECT * FROM client";

        $check_client = mysqli_query($conn, $table_client);

        if (!$check_client) {
            $create_client =   "CREATE TABLE  client(
              client_id INT AUTO_INCREMENT not null,
              first_name varchar(100) not null,
              last_name varchar(100) not null,
              client_code varchar(10) not null,
              primary key(client_id)
          );" ;



            if ($conn->query($create_client) === true) {
                echo "Table Client created successfully";
            } else {
                echo "Error creating table Client: " . $conn->error;
            }
        }

        #creatig table client_contact
        $table_client = "SELECT * FROM client_contact";

        $check_client_contact = mysqli_query($conn, $table_client);

        if (!$check_client_contact) {
            $create_client =  "CREATE TABLE client_contact(
             
              client_id int(20) not null,
              contact_id int(20) not null,
                client_code varchar(10) not null,
                email varchar(100) not null,
              FOREIGN KEY (client_id) REFERENCES client(client_id) ON DELETE RESTRICT ON UPDATE CASCADE,
              FOREIGN KEY (contact_id) REFERENCES contact(contact_id) ON DELETE RESTRICT ON UPDATE CASCADE,
              PRIMARY KEY (client_id,contact_id)
            );" ;



            if ($conn->query($create_client) === true) {
                echo "Table Client_Contact created successfully";
            } else {
                echo "Error creating table Client_Contact: " . $conn->error;
            }
        }


        // #creating the client_contact table
        $table_number = "SELECT * FROM client_code";
        $check_number = mysqli_query($conn, $table_number);

        if (!$check_number) {
            $create_number_table = "CREATE TABLE  client_code(
                    contact_id INT AUTO_INCREMENT not null primary key,
                    number int not null
                );";

            $insert_number = "INSERT INTO client_code(number) VALUES(100)";

            //     #validating the contact table creation
            $created_number = mysqli_query($conn, $create_number_table);

            if (!$created_number) {
                echo "Error creating table";
            } else {
                $insert_result = mysqli_query($conn, $insert_number);

                if (!$insert_result) {
                    echo "Error inserting row.";
                } else {
                    echo "Record successfully saved";
                }
                
                echo "Table successfully created!";
            }
        }
        // $conn->close();
        return $conn;
    }
}
